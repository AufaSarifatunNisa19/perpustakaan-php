<?php 

    $db = mysqli_connect("localhost", "root", "", "perpustakaan_saya")or die ("gagal terkoneksi");